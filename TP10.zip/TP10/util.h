
void convertIntIntoChar(int N, char * N4);

int convertStringIntoInt(char * c);

double convertPriceStringToInt(char * c);


